import Mock from "./mock";
import "./db/database";

Mock.onAny().passThrough();